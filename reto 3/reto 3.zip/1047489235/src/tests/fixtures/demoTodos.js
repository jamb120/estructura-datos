export const demoTodos = [{
    id: 1,
    desc: 'Aprender React',
    done: false
},{
    id: 2,
    desc: 'Aprender Mongo',
    done: false
}];