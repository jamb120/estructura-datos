import { HeroList } from '../hero/HeroList';


export const DcScreen = () => {
    return (
        <div>
            <h3>DCScreen</h3>
            <hr />

            <HeroList publisher="DC Comics" />

        </div>
    )
}
