import { HeroList } from '../hero/HeroList'


export const MarvelScreen = () => {
    return (
        <div>
            <h4>MarvelScreen</h4>
            <hr />

            <HeroList publisher="Marvel Comics" />

        </div>
    )
}
