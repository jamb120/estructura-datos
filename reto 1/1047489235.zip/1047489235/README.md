# CounterApp

Esta es nuestra primera aplicación de React. Recuerden que si desean ejecutar esta aplicación, deben de reconstruir los módulos de node así:

```
npm install
```

Y luego pueden correrlo así

```
npm start
```

